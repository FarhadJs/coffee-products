export enum UserRole {
  FOUNDER = 'founder',
  ADMIN = 'admin',
  STAFF = 'staff',
  USER = 'user',
}
