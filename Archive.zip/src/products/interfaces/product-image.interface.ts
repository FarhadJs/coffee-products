export interface ProductImage {
  data: Buffer;
  contentType: string;
  filename: string;
}
